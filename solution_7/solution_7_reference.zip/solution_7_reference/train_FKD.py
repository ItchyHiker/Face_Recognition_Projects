#!/usr/bin/env python
# encoding: utf-8
import os
import torch.utils.data
import logging
from torch.nn import DataParallel
from SEResNet_IR import ResNet34, ResNet18
from mobilefacenet import MobileFaceNet
from dataset.casia_webface import CASIAWebFace
from torch.optim import lr_scheduler
import torch.optim as optim
import time
import torchvision.transforms as transforms
import argparse
import logging as logger
logger.basicConfig(level=logger.INFO, format='%(levelname)s %(asctime)s %(filename)s: %(lineno)d] %(message)s',
                   datefmt='%Y-%m-%d %H:%M:%S')

def train(args):
    # gpu init
    multi_gpus = False
    if len(args.gpus.split(',')) > 1:
        multi_gpus = True
    os.environ['CUDA_VISIBLE_DEVICES'] = args.gpus
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # log init
    if os.path.exists(args.save_dir):
        pass
    else:
        os.makedirs(args.save_dir)

    # dataset loader
    transform = transforms.Compose([
        transforms.ToTensor(),  # range [0, 255] -> [0.0,1.0]
        transforms.Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5))  
    ])
    # train dataset
    trainset = CASIAWebFace(args.train_root, args.train_file_list, transform=transform)
    trainloader = torch.utils.data.DataLoader(trainset, batch_size=args.batch_size,
                                              shuffle=True, num_workers=8, drop_last=True)

    teacher_model = ResNet34()
    teacher_checkpoint = './checkpoints/best.pt'
    teacher_model.load_state_dict(torch.load(teacher_checkpoint)['net_state_dict'], strict=True)

    student_model = MobileFaceNet()
    if args.resume:
        logging.info('resume the model parameters from: ', args.net_path)
        student_model.load_state_dict(torch.load(args.net_path)['net_state_dict'])

    # define optimizers for different layer
    criterion_classi = torch.nn.MSELoss(reduction='sum').to(device)
    optimizer_classi = optim.SGD([
        {'params': student_model.parameters(), 'weight_decay': 5e-4},
    ], lr=0.1, momentum=0.9, nesterov=True)
    scheduler_classi = lr_scheduler.MultiStepLR(optimizer_classi, milestones=[20, 35, 45], gamma=0.1)

    if multi_gpus:
        teacher_model = DataParallel(teacher_model).to(device)
        student_model = DataParallel(student_model).to(device)
    else:
        teacher_model = teacher_model.to(device)
        student_model = student_model.to(device)

    for epoch in range(1, args.total_epoch + 1):
        # train model
        logger.info('Train Epoch: {}/{} ...'.format(epoch, args.total_epoch))
        student_model.train()
        teacher_model.eval()
        since = time.time()
        batch_idx = 0
        for data in trainloader:
            img, label = data[0].to(device), data[1].to(device)

            teacher_feature = teacher_model(img)
            student_feature = student_model(img)
            mse_loss = criterion_classi (student_feature, teacher_feature) / (2 * img.shape[0]) # 512维特征一致性

            optimizer_classi.zero_grad()
            mse_loss.backward()
            optimizer_classi.step()

            batch_idx += 1

        # save model
        if multi_gpus:
            net_state_dict = student_model.module.state_dict()
        else:
            net_state_dict = student_model.state_dict()

        if not os.path.exists(args.save_dir):
            os.mkdir(args.save_dir)
        save_name = 'epoch_%d.pt' % epoch
        torch.save({'net_state_dict': net_state_dict}, os.path.join(args.save_dir, save_name))

        scheduler_classi.step()
    logger.info('finishing training')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='PyTorch for deep face recognition')
    parser.add_argument('--train_root', type=str, default='./dataset/webcam_crop112', help='train image root')
    parser.add_argument('--train_file_list', type=str, default='./dataset/webcam_crop112_list.txt', help='train list')
    parser.add_argument('--batch_size', type=int, default=4, help='batch size')
    parser.add_argument('--total_epoch', type=int, default=50, help='total epochs')
    parser.add_argument('--save_freq', type=int, default=2000, help='save frequency')
    parser.add_argument('--resume', type=int, default=False, help='resume model')
    parser.add_argument('--net_path', type=str, default='', help='resume model')
    parser.add_argument('--save_dir', type=str, default='./FKD_chceckpoints', help='model save dir')
    parser.add_argument('--gpus', type=str, default='0', help='model prefix')

    args = parser.parse_args()

    train(args)


